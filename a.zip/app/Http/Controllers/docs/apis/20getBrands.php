<?php
return
[
    'name'=>'getBrands',
    'description'=>'this api used to get brands in the application',
    'params'=>
        [


        ],
    'response'=>[
        [
            'status'=>200,
            'params'=>[
                'brands'=>'array of <a href="#brand">brand</a>'

            ],
        ],

    ]
];
