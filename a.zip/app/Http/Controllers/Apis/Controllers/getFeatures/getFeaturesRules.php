<?php
namespace App\Http\Controllers\Apis\Controllers\getFeatures;

use App\Http\Controllers\Apis\Controllers\index;
use App\Http\Controllers\Apis\Resources\objects;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Apis\Helper\helper;

class getFeaturesRules extends index
{
    public static function rules ()
    {

    }
}
