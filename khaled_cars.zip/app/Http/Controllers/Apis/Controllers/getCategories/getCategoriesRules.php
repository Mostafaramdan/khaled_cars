<?php
namespace App\Http\Controllers\Apis\Controllers\getCategories;

use App\Http\Controllers\Apis\Controllers\index;
use App\Http\Controllers\Apis\Resources\objects;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Apis\Helper\helper;

class getCategoriesRules extends index
{
    public static function rules ()
    {
        return null;
    }
}
